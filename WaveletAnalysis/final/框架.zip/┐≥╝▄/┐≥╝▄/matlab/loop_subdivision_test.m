[x, t] = readObj('ball.obj');

figure; subplot(121); trimesh(t, x(:,1), x(:,2), x(:,3), 'edgecolor', 'k'); axis equal; axis off; title('coarse mesh');



%% TODO: finish the loop subdivision algorithm below 
function [x2, t2] = loop(x, t, n)
    
end