## Machine Learning Lab1

Logistic Regression

By Chen Zegao(PB20000302) 2022.10.18

### 1 Logistic Regression

I use Gradient-Descent method to do Maximum Likelihood Estimation, the model is in ```Logistic.py```

### 2 Data

[Loan Data Set | Kaggle](https://www.kaggle.com/datasets/burak3ergun/loan-data-set)

### 3 What have I done

I choose the supplied frame to do this project

* In `Logistic.py`, I have written my Logistic Regression class

* In `Load.ipynb`, I have:

    1. dropped the NULL rows
    2. Encoded categorical features, trying to make them close to $1$
    3. Splited the dataset into X_train, X_test, y_train, y_test
    4. Trained the model and plotted the loss curve of training
    5. Compare the accuracy of test data with different parameters, such as learning rate and regularization parameter

As you can see, you can check all my results in ```Load.ipynb```, and run the notebook to verify them.
